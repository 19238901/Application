﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Timers;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace CPS
{
    /// <summary>
    /// Page1.xaml の相互作用ロジック
    /// </summary>
    public partial class Page9402 : Page
    {
        List<Page4.user> u6 = new List<Page4.user>();
        string p_name = "";
        string p_labo = "";
        string s_id = "";
        string s_name = "";
        string s_labo = "";
        string s_room = "";
        string s_date = "";
        string x;
        string y;
        public Page9402(string p_name, string p_labo, string id, string name, string labo, string room, string date)
        {
            InitializeComponent();
            this.p_name = p_name;
            this.p_labo = p_labo;
            this.s_id = id;
            this.s_name = name;
            this.s_labo = labo;
            this.s_room = room;
            this.s_date = date;

            ROOM.IsReadOnly = true;
            ROOM.Text = room;

            SqlConnection sqlconn = new SqlConnection(Properties.Settings.Default.sqlServer);
            using (var command = sqlconn.CreateCommand())
            {
                sqlconn.Open();
                // SQLの設定
                command.CommandText = @"SELECT id,name,labo,status,room,place_x,place_y,dt FROM cps_log";

                // SQLの実行
                using (var reader = command.ExecuteReader())
                {
                    while (reader.Read() == true)
                    {
                        Page4.user nu = new Page4.user();
                        nu.id = reader["id"] as string;
                        nu.name = reader["name"] as string;
                        nu.affiliations = reader["labo"] as string;
                        nu.status = reader["status"] as string;
                        nu.room = reader["room"] as string;
                        nu.place_x = reader["place_x"] as string;
                        nu.place_y = reader["place_y"] as string;
                        nu.dt = reader["dt"] as string;
                        u6.Add(nu);
                    }
                }
                sqlconn.Close();
            }
        }
        private void Search(string x, string y)
        {
            var page9 = new Page9(p_name, p_labo, s_id, s_name, s_labo, s_room, x, y, s_date, "ALL");
            NavigationService.Navigate(page9);
        }
        //11
        private void Button_Click_11(object sender, RoutedEventArgs e)
        {
            x = "1";
            y = "1";
            Search(x, y);
        }
        //12
        private void Button_Click_12(object sender, RoutedEventArgs e)
        {
            x = "2";
            y = "1";
            Search(x, y);
        }
        //13
        private void Button_Click_13(object sender, RoutedEventArgs e)
        {
            x = "3";
            y = "1";
            Search(x, y);
        }
        //14
        private void Button_Click_14(object sender, RoutedEventArgs e)
        {
            x = "4";
            y = "1";
            Search(x, y);
        }
        //15
        private void Button_Click_15(object sender, RoutedEventArgs e)
        {
            x = "5";
            y = "1";
            Search(x, y);
        }
        //16
        private void Button_Click_16(object sender, RoutedEventArgs e)
        {
            x = "6";
            y = "1";
            Search(x, y);
        }
        //21
        private void Button_Click_21(object sender, RoutedEventArgs e)
        {
            x = "1";
            y = "2";
            Search(x, y);
        }
        //22
        private void Button_Click_22(object sender, RoutedEventArgs e)
        {
            x = "2";
            y = "2";
            Search(x, y);
        }
        //23
        private void Button_Click_23(object sender, RoutedEventArgs e)
        {
            x = "3";
            y = "2";
            Search(x, y);
        }
        //24
        private void Button_Click_24(object sender, RoutedEventArgs e)
        {
            x = "4";
            y = "2";
            Search(x, y);
        }
        //25
        private void Button_Click_25(object sender, RoutedEventArgs e)
        {
            x = "5";
            y = "2";
            Search(x, y);
        }
        //26
        private void Button_Click_26(object sender, RoutedEventArgs e)
        {
            x = "6";
            y = "2";
            Search(x, y);
        }
        //31
        private void Button_Click_31(object sender, RoutedEventArgs e)
        {
            x = "1";
            y = "3";
            Search(x, y);
        }
        //32
        private void Button_Click_32(object sender, RoutedEventArgs e)
        {
            x = "2";
            y = "3";
            Search(x, y);
        }
        //33
        private void Button_Click_33(object sender, RoutedEventArgs e)
        {
            x = "3";
            y = "3";
            Search(x, y);
        }
        //34
        private void Button_Click_34(object sender, RoutedEventArgs e)
        {
            x = "4";
            y = "3";
            Search(x, y);
        }
        //35
        private void Button_Click_35(object sender, RoutedEventArgs e)
        {
            x = "5";
            y = "3";
            Search(x, y);
        }
        //36
        private void Button_Click_36(object sender, RoutedEventArgs e)
        {
            x = "6";
            y = "3";
            Search(x, y);
        }
        //41
        private void Button_Click_41(object sender, RoutedEventArgs e)
        {
            x = "1";
            y = "4";
            Search(x, y);
        }
        //42
        private void Button_Click_42(object sender, RoutedEventArgs e)
        {
            x = "2";
            y = "4";
            Search(x, y);
        }
        //43
        private void Button_Click_43(object sender, RoutedEventArgs e)
        {
            x = "3";
            y = "4";
            Search(x, y);
        }
        //HOME
        private void Button_Click_HOME(object sender, RoutedEventArgs e)
        {
            var page3 = new Page3(p_name, p_labo);
            NavigationService.Navigate(page3);
        }
        //<-
        private void Button_Click(object sender, RoutedEventArgs e)
        {
            var page8 = new Page91(p_name, p_labo, s_id, s_name, s_labo, s_room, s_date);
            NavigationService.Navigate(page8);
        }
        //PROFESSOR
        private void Button_Click_pro(object sender, RoutedEventArgs e)
        {
            var page8pro = new Page9(p_name, p_labo, s_id, s_name, s_labo, "PROFESSOR", "", "", s_date, "ALL");
            NavigationService.Navigate(page8pro);
        }
        //402
        private void Button_Click_402(object sender, RoutedEventArgs e)
        {
            var page8402 = new Page9402(p_name, p_labo, s_id, s_name, s_labo, "402", s_date);
            NavigationService.Navigate(page8402);
        }
        //403
        private void Button_Click_403(object sender, RoutedEventArgs e)
        {
            var page8403 = new Page9403(p_name, p_labo, s_id, s_name, s_labo, "403", s_date);
            NavigationService.Navigate(page8403);
        }
        //404
        private void Button_Click_404(object sender, RoutedEventArgs e)
        {
            var page8404 = new Page9404(p_name, p_labo, s_id, s_name, s_labo, "404", s_date);
            NavigationService.Navigate(page8404);
        }
        //OTHER
        private void Button_Click_OTHER(object sender, RoutedEventArgs e)
        {
            var page8other = new Page9(p_name, p_labo, s_id, s_name, s_labo, "OTHER", "", "", s_date, "ALL");
            NavigationService.Navigate(page8other);
        }
    }
}