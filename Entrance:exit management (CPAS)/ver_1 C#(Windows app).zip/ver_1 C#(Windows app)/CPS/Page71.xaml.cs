﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Timers;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace CPS
{
    /// <summary>
    /// Page1.xaml の相互作用ロジック
    /// </summary>
    public partial class Page71 : Page
    {
        System.Collections.ObjectModel.ObservableCollection<Page4.user> res = new System.Collections.ObjectModel.ObservableCollection<Page4.user>();

        List<Page1.user> u1 = new List<Page1.user>();
        List<Page4.user> uInfo = new List<Page4.user>();
        string p_id = "";
        string p_name = "";
        string p_labo = "";
        string s_id = "";
        string s_name = "";
        string s_labo = "";
        string s_room = "";
        string s = "";
        public Page71(string p_name, string p_labo, string s_id, string s_name, string s_labo, string s_room)
        {
            InitializeComponent();

            this.p_name = p_name;
            this.p_labo = p_labo;
            this.s_id = s_id;
            this.s_name = s_name;
            this.s_labo = s_labo;
            this.s_room = s_room;

            SqlConnection sqlconn = new SqlConnection(Properties.Settings.Default.sqlServer);
            using (var command = sqlconn.CreateCommand())
            {
                sqlconn.Open();
                // SQLの設定
                command.CommandText = @"SELECT id,name,pass,labo FROM cps_user";

                // SQLの実行
                using (var reader = command.ExecuteReader())
                {
                    while (reader.Read() == true)
                    {
                        Page1.user nu = new Page1.user();
                        nu.id = reader["id"] as string;
                        nu.name = reader["name"] as string;
                        nu.pass = reader["pass"] as string;
                        nu.affiliations = reader["labo"] as string;
                        u1.Add(nu);
                    }
                }
            }
            p_id = u1.Find(u => u.name == p_name).id;

            Search.IsReadOnly = true;

            Search.Text = "ID:" + s_id + " Name:" + s_name + " Labo:" + s_labo + " Room:" + s_room;
            using (var command = sqlconn.CreateCommand())
            {
                // SQLの設定
                command.CommandText = @"SELECT id,name,labo,status,room,place_x,place_y,dt FROM cps_info";

                // SQLの実行
                using (var reader = command.ExecuteReader())
                {
                    while (reader.Read() == true)
                    {
                        Page4.user nu = new Page4.user();
                        nu.id = reader["id"] as string;
                        nu.name = reader["name"] as string;
                        nu.affiliations = reader["labo"] as string;
                        nu.status = reader["status"] as string;
                        nu.room = reader["room"] as string;
                        nu.place_x = reader["place_x"] as string;
                        nu.place_y = reader["place_y"] as string;
                        nu.dt = reader["dt"] as string;
                        uInfo.Add(nu);
                    }
                }
                sqlconn.Close();
            }
            s = s_id + "/" + s_name + "/" + s_labo + "/" + s_room;
            saveStatus(s);
            try
            {
                if (s == "///")
                {
                    uInfo = uInfo.FindAll(u => u.status != "LEAVE");
                }
                else
                {
                    if (s_id != "")
                    {
                        uInfo = uInfo.FindAll(u => u.id == s_id);
                    }
                    if (s_name != "")
                    {
                        uInfo = uInfo.FindAll(u => u.name == s_name);
                    }
                    if (s_labo != "")
                    {
                        uInfo = uInfo.FindAll(u => u.affiliations == s_labo);
                    }
                    if (s_room != "")
                    {
                        uInfo = uInfo.FindAll(u => u.room == s_room);
                    }
                }
            }
            catch
            {

            }
            int c = uInfo.Count();
            if (c != 0)
            {
                Page4.user userf = uInfo.First();
                for (int i = 0; i < c; i++)
                {
                    res.Add(new Page4.user() { id = userf.id, name = userf.name, affiliations = userf.affiliations, status = userf.status, room = userf.room, dt = userf.dt });

                    uInfo.Remove(userf);
                    if (uInfo.Count() != 0)
                    {
                        userf = uInfo.First();
                    }
                }
                lvUsers.ItemsSource = res;
            }
        }
        public void saveStatus(string str)
        {
            SqlConnection sqlconn = new SqlConnection(Properties.Settings.Default.sqlServer);
            sqlconn.Open();
            DateTime dt = DateTime.Now;
            string SqlWord = "insert into cps_log(id,name,labo,status,room,place_x,place_y,dt) VALUES (@id,@name,@labo,@status,@room,@place_x,@place_y,@dt)";
            using (SqlTransaction transaction = sqlconn.BeginTransaction())
            {
                using (SqlCommand cmd = new SqlCommand(SqlWord, sqlconn, transaction))
                {
                    cmd.Parameters.Add(new SqlParameter(
                        "@id", SqlDbType.VarChar)).Value = p_id;
                    cmd.Parameters.Add(new SqlParameter(
                        "@name", SqlDbType.VarChar)).Value = p_name;
                    cmd.Parameters.Add(new SqlParameter(
                        "@labo", SqlDbType.VarChar)).Value = p_labo;
                    cmd.Parameters.Add(new SqlParameter(
                        "@status", SqlDbType.VarChar)).Value = "SEARCH";
                    cmd.Parameters.Add(new SqlParameter(
                        "@room", SqlDbType.VarChar)).Value = str;
                    cmd.Parameters.Add(new SqlParameter(
                        "@place_x", SqlDbType.VarChar)).Value = "0";
                    cmd.Parameters.Add(new SqlParameter(
                        "@place_y", SqlDbType.VarChar)).Value = "0";
                    cmd.Parameters.Add(new SqlParameter(
                        "@dt", SqlDbType.VarChar)).Value = dt.ToString("yyyy/MM/dd HH:mm:ss");
                    cmd.ExecuteNonQuery();

                    transaction.Commit();
                }
            }
            sqlconn.Close();
        }
        //VIEWS
        private void Button_Click(object sender, RoutedEventArgs e)
        {
            var page8 = new Page8(p_name, p_labo);
            NavigationService.Navigate(page8);
        }
        //HOME
        private void Button_Click_HOME(object sender, RoutedEventArgs e)
        {
            var page3 = new Page3(p_name, p_labo);
            NavigationService.Navigate(page3);
        }

        private void Button_Click_back(object sender, RoutedEventArgs e)
        {
            var page7 = new Page7(p_name, p_labo);
            NavigationService.Navigate(page7);
        }
    }
}