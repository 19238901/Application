﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Timers;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace CPS
{
    /// <summary>
    /// Page1.xaml の相互作用ロジック
    /// </summary>
    public partial class Page4 : Page
    {
        public class user
        {
            public string id { get; set; }
            public string name { get; set; }
            public string affiliations { get; set; }
            public string status { get; set; }
            public string room { get; set; }
            public string place_x { get; set; }
            public string place_y { get; set; }
            public string dt { get; set; }
        }
        List<Page1.user> u1 = new List<Page1.user>();
        List<user> u1n = new List<user>();
        List<user> uInfo = new List<user>();
        string status = "";
        string s_id = "";
        public Page4(string p_Name, string p_Labo)
        {
            InitializeComponent();

            SqlConnection sqlconn = new SqlConnection(Properties.Settings.Default.sqlServer);
            using (var command = sqlconn.CreateCommand())
            {
                sqlconn.Open();
                // SQLの設定
                command.CommandText = @"SELECT id,name,pass,labo FROM cps_user";

                // SQLの実行
                using (var reader = command.ExecuteReader())
                {
                    while (reader.Read() == true)
                    {
                        Page1.user nu = new Page1.user();
                        nu.id = reader["id"] as string;
                        nu.name = reader["name"] as string;
                        nu.pass = reader["pass"] as string;
                        nu.affiliations = reader["labo"] as string;
                        u1.Add(nu);
                    }
                }
                // SQLの設定
                command.CommandText = @"SELECT id,name,labo,status,room,place_x,place_y,dt FROM cps_info";

                // SQLの実行
                using (var reader = command.ExecuteReader())
                {
                    while (reader.Read() == true)
                    {
                        user nu = new user();
                        nu.id = reader["id"] as string;
                        nu.name = reader["name"] as string;
                        nu.affiliations = reader["labo"] as string;
                        nu.status = reader["status"] as string;
                        nu.room = reader["room"] as string;
                        nu.place_x = reader["place_x"] as string;
                        nu.place_y = reader["place_y"] as string;
                        nu.dt = reader["dt"] as string;
                        uInfo.Add(nu);
                    }
                }
                sqlconn.Close();
            }
            Player_Info.IsReadOnly = true;
            Player_Labo.IsReadOnly = true;
            if (p_Name == "")
            {
                p_Name = "Guest";
            }
            if (p_Labo == "")
            {
                p_Labo = "-";
            }
            Player_Info.Text = p_Name;
            Player_Labo.Text = p_Labo;

            s_id = u1.Find(u => u.name == Player_Info.Text).id;
        }
        public void saveStatus(string str)
        {
            SqlConnection sqlconn = new SqlConnection(Properties.Settings.Default.sqlServer);
            sqlconn.Open();
            DateTime dt = DateTime.Now;
            string SqlWord = "insert into cps_log(id,name,labo,status,room,place_x,place_y,dt) VALUES (@id,@name,@labo,@status,@room,@place_x,@place_y,@dt)";
            using (SqlTransaction transaction = sqlconn.BeginTransaction())
            {
                using (SqlCommand cmd = new SqlCommand(SqlWord, sqlconn, transaction))
                {
                    cmd.Parameters.Add(new SqlParameter(
                        "@id", SqlDbType.VarChar)).Value = s_id;
                    cmd.Parameters.Add(new SqlParameter(
                        "@name", SqlDbType.VarChar)).Value = Player_Info.Text;
                    cmd.Parameters.Add(new SqlParameter(
                        "@labo", SqlDbType.VarChar)).Value = Player_Labo.Text;
                    cmd.Parameters.Add(new SqlParameter(
                        "@status", SqlDbType.VarChar)).Value = str;
                    cmd.Parameters.Add(new SqlParameter(
                        "@room", SqlDbType.VarChar)).Value = "-";
                    cmd.Parameters.Add(new SqlParameter(
                        "@place_x", SqlDbType.VarChar)).Value = "0";
                    cmd.Parameters.Add(new SqlParameter(
                        "@place_y", SqlDbType.VarChar)).Value = "0";
                    cmd.Parameters.Add(new SqlParameter(
                        "@dt", SqlDbType.VarChar)).Value = dt.ToString("yyyy/MM/dd HH:mm:ss");
                    cmd.ExecuteNonQuery();

                    transaction.Commit();
                }
            }
            SqlWord = "UPDATE cps_info SET id=@id,name=@name,labo=@labo,status=@status,room=@room,place_x=@place_x,place_y=@place_y,dt=@dt WHERE id=@id";
            using (SqlTransaction transaction = sqlconn.BeginTransaction())
            {
                using (SqlCommand cmd = new SqlCommand(SqlWord, sqlconn, transaction))
                {
                    cmd.Parameters.Add(new SqlParameter(
                        "@id", SqlDbType.VarChar)).Value = s_id;
                    cmd.Parameters.Add(new SqlParameter(
                        "@name", SqlDbType.VarChar)).Value = Player_Info.Text;
                    cmd.Parameters.Add(new SqlParameter(
                        "@labo", SqlDbType.VarChar)).Value = Player_Labo.Text;
                    cmd.Parameters.Add(new SqlParameter(
                        "@status", SqlDbType.VarChar)).Value = str;
                    cmd.Parameters.Add(new SqlParameter(
                        "@room", SqlDbType.VarChar)).Value = "-";
                    cmd.Parameters.Add(new SqlParameter(
                        "@place_x", SqlDbType.VarChar)).Value = "0";
                    cmd.Parameters.Add(new SqlParameter(
                        "@place_y", SqlDbType.VarChar)).Value = "0";
                    cmd.Parameters.Add(new SqlParameter(
                        "@dt", SqlDbType.VarChar)).Value = dt.ToString("yyyy/MM/dd HH:mm:ss");
                    cmd.ExecuteNonQuery();

                    transaction.Commit();
                }
            }
            sqlconn.Close();
        }
        //ENTERボタン
        private void Button_Ckick_ENTER(object sender, RoutedEventArgs e)
        {
            status = "ENTER";
            var page5 = new Page5(s_id, Player_Info.Text, Player_Labo.Text, status);
            NavigationService.Navigate(page5);
        }
        //LEAVE
        private void Button_Click_LEAVE(object sender, RoutedEventArgs e)
        {
            status = "LEAVE";
            saveStatus(status);
            MessageBox.Show("Thank you for your hard work.");
            var page1 = new Page1();
            NavigationService.Navigate(page1);
        }
        //CLASS
        private void Button_Click_CLASS(object sender, RoutedEventArgs e)
        {
            status = "CLASS";
            var page5 = new Page5(s_id, Player_Info.Text, Player_Labo.Text, status);
            NavigationService.Navigate(page5);
        }
        //MEETING
        private void Button_Click_MEETING(object sender, RoutedEventArgs e)
        {
            status = "MEETING";
            var page5 = new Page5(s_id, Player_Info.Text, Player_Labo.Text, status);
            NavigationService.Navigate(page5);
        }
        //EXPERIMENT
        private void Button_Ckick_EXPERIMENT(object sender, RoutedEventArgs e)
        {
            status = "EXPERIMENT";
            var page5 = new Page5(s_id, Player_Info.Text, Player_Labo.Text, status);
            NavigationService.Navigate(page5);
        }
        //OTHER
        private void Button_Click_OTHER(object sender, RoutedEventArgs e)
        {
            status = "OTHER";
            var page5 = new Page5(s_id, Player_Info.Text, Player_Labo.Text, status);
            NavigationService.Navigate(page5);
        }
        //HOME
        private void Button_Click_HOME(object sender, RoutedEventArgs e)
        {
            var page3 = new Page3(Player_Info.Text, Player_Labo.Text);
            NavigationService.Navigate(page3);
        }
    }
}