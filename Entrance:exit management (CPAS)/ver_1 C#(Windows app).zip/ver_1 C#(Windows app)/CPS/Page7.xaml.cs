﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace CPS
{
    /// <summary>
    /// Page5.xaml の相互作用ロジック
    /// </summary>

    public partial class Page7 : Page
    {
        List<Page4.user> uInfo = new List<Page4.user>();
        string p_name = "";
        string p_labo = "";
        string s_id = "";
        string s_name = "";
        string s_labo = "";
        string s_room = "";

        public Page7(string p_name, string p_from)
        {
            InitializeComponent();
            this.p_name = p_name;
            this.p_labo = p_from;
        }
        //SEARCH
        private void Button_Click(object sender, RoutedEventArgs e)
        {
            if(Player_Id.Text != "")
            {
                s_id = Player_Id.Text;
            }
            if(Player_Name.Text != "")
            {
                s_name = Player_Name.Text;
            }
            if(Player_From.Text != "")
            {
                s_labo = Player_From.Text;
            }
            if(ROOM.Text != "")
            {
                s_room = ROOM.Text;
            }
            var page71 = new Page71(p_name, p_labo, s_id, s_name, s_labo, s_room);
            NavigationService.Navigate(page71);
        }
        //HOME
        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
            var page3 = new Page3(p_name, p_labo);
            NavigationService.Navigate(page3);
        }
        //ALL CLEAR
        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            Player_Id.Text = "";
            Player_Name.Text = "";
            ROOM.Text = "";
            Player_From.Text = "";
        }
    }
}
