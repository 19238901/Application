﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Timers;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace CPS
{
    /// <summary>
    /// Page1.xaml の相互作用ロジック
    /// </summary>
    public partial class Page8other : Page
    {
        public class user
        {
            public string id { get; set; }
            public string name { get; set; }
            public string affiliations { get; set; }
            public string status { get; set; }
            public string room { get; set; }
            public string dt { get; set; }
        }
        System.Collections.ObjectModel.ObservableCollection<user> res = new System.Collections.ObjectModel.ObservableCollection<user>();


        List<Page1.user> u1 = new List<Page1.user>();
        List<user> uInfo = new List<user>();
        string p_id = "";
        string p_name = "";
        string p_labo = "";
        string status = "";
        string room = "";
        public Page8other(string p_id, string p_name, string p_labo, string status, string room)
        {
            InitializeComponent();

            this.p_id = p_id;
            this.p_name = p_name;
            this.p_labo = p_labo;
            this.status = status;
            this.room = room;
            ROOM.Text = room;
            ROOM.IsReadOnly = true;

            SqlConnection sqlconn = new SqlConnection(Properties.Settings.Default.sqlServer);
            using (var command = sqlconn.CreateCommand())
            {
                sqlconn.Open();
                // SQLの設定
                command.CommandText = @"SELECT id,name,labo,status,room,dt FROM cps_info";

                // SQLの実行
                using (var reader = command.ExecuteReader())
                {
                    while (reader.Read() == true)
                    {
                        user nu = new user();
                        nu.id = reader["id"] as string;
                        nu.name = reader["name"] as string;
                        nu.affiliations = reader["labo"] as string;
                        nu.status = reader["status"] as string;
                        nu.room = reader["room"] as string;
                        nu.dt = reader["dt"] as string;
                        uInfo.Add(nu);
                    }
                }
                sqlconn.Close();
            }
            List<user> s_user = new List<user>();
            s_user = uInfo.FindAll(u => u.room == "OTHER");
            int c = s_user.Count();
            if (c != 0)
            {
                user userf = s_user.First();

                for (int i = 0; i < c; i++)
                {
                    res.Add(new user() { id = userf.id, name = userf.name, affiliations = userf.affiliations, status = userf.status, room = userf.room, dt = userf.dt });

                    s_user.Remove(userf);
                    if (s_user.Count() != 0)
                    {
                        userf = s_user.First();
                    }
                }
                Other.ItemsSource = res;
            }
        }
        //VIEWS
        private void Button_Click(object sender, RoutedEventArgs e)
        {
            var page8 = new Page8(p_name, p_labo);
            NavigationService.Navigate(page8);
        }
        //HOME
        private void Button_Click_HOME(object sender, RoutedEventArgs e)
        {
            var page3 = new Page3(p_name, p_labo);
            NavigationService.Navigate(page3);
        }
        //<-
        private void Button_Click_back(object sender, RoutedEventArgs e)
        {
            var page7 = new Page7(p_name, p_labo);
            NavigationService.Navigate(page7);
        }
        public void saveStatus(string str, string room)
        {
            SqlConnection sqlconn = new SqlConnection(Properties.Settings.Default.sqlServer);
            sqlconn.Open();
            DateTime dt = DateTime.Now;
            string SqlWord = "insert into cps_log(id,name,labo,status,room,place_x,place_y,dt) VALUES (@id,@name,@labo,@status,@room,@place_x,@place_y,@dt)";
            using (SqlTransaction transaction = sqlconn.BeginTransaction())
            {
                using (SqlCommand cmd = new SqlCommand(SqlWord, sqlconn, transaction))
                {
                    cmd.Parameters.Add(new SqlParameter(
                        "@id", SqlDbType.VarChar)).Value = p_id;
                    cmd.Parameters.Add(new SqlParameter(
                        "@name", SqlDbType.VarChar)).Value = p_name;
                    cmd.Parameters.Add(new SqlParameter(
                        "@labo", SqlDbType.VarChar)).Value = p_labo;
                    cmd.Parameters.Add(new SqlParameter(
                        "@status", SqlDbType.VarChar)).Value = str;
                    cmd.Parameters.Add(new SqlParameter(
                        "@room", SqlDbType.VarChar)).Value = room;
                    cmd.Parameters.Add(new SqlParameter(
                        "@place_x", SqlDbType.VarChar)).Value = "0";
                    cmd.Parameters.Add(new SqlParameter(
                        "@place_y", SqlDbType.VarChar)).Value = "0";
                    cmd.Parameters.Add(new SqlParameter(
                        "@dt", SqlDbType.VarChar)).Value = dt.ToString("yyyy/MM/dd HH:mm:ss");
                    cmd.ExecuteNonQuery();

                    transaction.Commit();
                }
            }
        }
        //PROFESSOR
        private void Button_Click_pro(object sender, RoutedEventArgs e)
        {
            saveStatus(status, "PROFESSOR");
            var page8pro = new Page8pro(p_id, p_name, p_labo, status, "PROFESSOR");
            NavigationService.Navigate(page8pro);
        }
        //402
        private void Button_Click_402(object sender, RoutedEventArgs e)
        {
            saveStatus(status, "402");
            var page8402 = new Page8402(p_id, p_name, p_labo, status, "402");
            NavigationService.Navigate(page8402);
        }
        //403
        private void Button_Click_403(object sender, RoutedEventArgs e)
        {
            saveStatus(status, "403");
            var page8403 = new Page8403(p_id, p_name, p_labo, status, "403");
            NavigationService.Navigate(page8403);
        }
        //404
        private void Button_Click_404(object sender, RoutedEventArgs e)
        {
            saveStatus(status, "404");
            var page8404 = new Page8404(p_id, p_name, p_labo, status, "404");
            NavigationService.Navigate(page8404);
        }
        //OTHER
        private void Button_Click_OTHER(object sender, RoutedEventArgs e)
        {
            saveStatus(status, "OTHER");
            var page8other = new Page8other(p_id, p_name, p_labo, status, "OTHER");
            NavigationService.Navigate(page8other);
        }
    }
}