﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Timers;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace CPS
{
    /// <summary>
    /// Page1.xaml の相互作用ロジック
    /// </summary>
    public partial class Page5 : Page
    {
        List<Page4.user> uInfo = new List<Page4.user>();
        string status = "";
        string room = "";
        string p_id = "";
        string p_name = "";
        string p_labo = "";
        public Page5(string p_id, string p_name, string p_labo, string p_status)
        {
            InitializeComponent();
            this.p_id = p_id;
            this.p_name = p_name;
            this.p_labo = p_labo;
            this.status = p_status;

            Player_Info.IsReadOnly = true;
            Player_Labo.IsReadOnly = true;
            
            Player_Info.Text = p_name;
            Player_Labo.Text = p_labo;

            SqlConnection sqlconn = new SqlConnection(Properties.Settings.Default.sqlServer);
            using (var command = sqlconn.CreateCommand())
            {
                sqlconn.Open();
                // SQLの設定
                command.CommandText = @"SELECT id,name,labo,status,room,place_x,place_y,dt FROM cps_info";

                // SQLの実行
                using (var reader = command.ExecuteReader())
                {
                    while (reader.Read() == true)
                    {
                        Page4.user nu = new Page4.user();
                        nu.id = reader["id"] as string;
                        nu.name = reader["name"] as string;
                        nu.affiliations = reader["labo"] as string;
                        nu.status = reader["status"] as string;
                        nu.room = reader["room"] as string;
                        nu.place_x = reader["place_x"] as string;
                        nu.place_y = reader["place_y"] as string;
                        nu.dt = reader["dt"] as string;
                        uInfo.Add(nu);
                    }
                }
                sqlconn.Close();
            }
        }
        public void saveStatus(string str, string room)
        {
            SqlConnection sqlconn = new SqlConnection(Properties.Settings.Default.sqlServer);
            sqlconn.Open();
            DateTime dt = DateTime.Now;
            string SqlWord = "insert into cps_log(id,name,labo,status,room,place_x,place_y,dt) VALUES (@id,@name,@labo,@status,@room,@place_x,@place_y,@dt)";
            using (SqlTransaction transaction = sqlconn.BeginTransaction())
            {
                using (SqlCommand cmd = new SqlCommand(SqlWord, sqlconn, transaction))
                {
                    cmd.Parameters.Add(new SqlParameter(
                        "@id", SqlDbType.VarChar)).Value = p_id;
                    cmd.Parameters.Add(new SqlParameter(
                        "@name", SqlDbType.VarChar)).Value = Player_Info.Text;
                    cmd.Parameters.Add(new SqlParameter(
                        "@labo", SqlDbType.VarChar)).Value = Player_Labo.Text;
                    cmd.Parameters.Add(new SqlParameter(
                        "@status", SqlDbType.VarChar)).Value = str;
                    cmd.Parameters.Add(new SqlParameter(
                        "@room", SqlDbType.VarChar)).Value = room;
                    cmd.Parameters.Add(new SqlParameter(
                        "@place_x", SqlDbType.VarChar)).Value = "0";
                    cmd.Parameters.Add(new SqlParameter(
                        "@place_y", SqlDbType.VarChar)).Value = "0";
                    cmd.Parameters.Add(new SqlParameter(
                        "@dt", SqlDbType.VarChar)).Value = dt.ToString("yyyy/MM/dd HH:mm:ss");
                    cmd.ExecuteNonQuery();

                    transaction.Commit();
                }
            }
            SqlWord = "update cps_info set id=@id,name=@name,labo=@labo,status=@status,room=@room,place_x=@place_x,place_y=@place_y,dt=@dt WHERE id = @id";
            using (SqlTransaction transaction = sqlconn.BeginTransaction())
            {
                using (SqlCommand cmd = new SqlCommand(SqlWord, sqlconn, transaction))
                {
                    cmd.Parameters.Add(new SqlParameter(
                        "@id", SqlDbType.VarChar)).Value = p_id;
                    cmd.Parameters.Add(new SqlParameter(
                        "@name", SqlDbType.VarChar)).Value = Player_Info.Text;
                    cmd.Parameters.Add(new SqlParameter(
                        "@labo", SqlDbType.VarChar)).Value = Player_Labo.Text;
                    cmd.Parameters.Add(new SqlParameter(
                        "@status", SqlDbType.VarChar)).Value = str;
                    cmd.Parameters.Add(new SqlParameter(
                        "@room", SqlDbType.VarChar)).Value = room;
                    cmd.Parameters.Add(new SqlParameter(
                        "@place_x", SqlDbType.VarChar)).Value = "0";
                    cmd.Parameters.Add(new SqlParameter(
                        "@place_y", SqlDbType.VarChar)).Value = "0";
                    cmd.Parameters.Add(new SqlParameter(
                        "@dt", SqlDbType.VarChar)).Value = dt.ToString("yyyy/MM/dd HH:mm:ss");
                    cmd.ExecuteNonQuery();

                    transaction.Commit();
                }
            }
            sqlconn.Close();
            MessageBox.Show("Registration complete!\nstatus:"+str+"\nroom:"+room);
        }
        //204
        private void Button_Click_204(object sender, RoutedEventArgs e)
        {
            room = "204";
            saveStatus(status, room);
        }
        //205
        private void Button_Click_205(object sender, RoutedEventArgs e)
        {
            room = "205";
            saveStatus(status, room);
        }
        //206
        private void Button_Click_206(object sender, RoutedEventArgs e)
        {
            room = "206";
            saveStatus(status, room);
        }
        //402
        private void Button_Click_402(object sender, RoutedEventArgs e)
        {
            room = "402";
            var page6402 = new Page6402(p_id, p_name, p_labo, status, room);
            NavigationService.Navigate(page6402);
        }
        //403
        private void Button_Click_403(object sender, RoutedEventArgs e)
        {
            room = "403";
            var page6403 = new Page6403(p_id, p_name, p_labo, status, room);
            NavigationService.Navigate(page6403);
        }
        //404
        private void Button_Click_404(object sender, RoutedEventArgs e)
        {
            room = "404";
            var page6404 = new Page6404(p_id, p_name, p_labo, status, room);
            NavigationService.Navigate(page6404);
        }
        //OTHER
        private void Button_Click_OTHER(object sender, RoutedEventArgs e)
        {
            room = "OTHER";
            saveStatus(status, room);
        }
        //HOME
        private void Button_Click_HOME(object sender, RoutedEventArgs e)
        {
            var page3 = new Page3(Player_Info.Text, Player_Labo.Text);
            NavigationService.Navigate(page3);
        }
        //<-
        private void Button_Click_back(object sender, RoutedEventArgs e)
        {
            var page4 = new Page4(Player_Info.Text, Player_Labo.Text);
            NavigationService.Navigate(page4);
        }
    }
}