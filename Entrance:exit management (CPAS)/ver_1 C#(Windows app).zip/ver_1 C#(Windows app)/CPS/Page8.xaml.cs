﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Timers;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace CPS
{
    /// <summary>
    /// Page1.xaml の相互作用ロジック
    /// </summary>
    public partial class Page8 : Page
    {
        List<Page4.user> uInfo = new List<Page4.user>();
        string room = "";
        string p_id = "";
        string p_name = "";
        string p_labo = "";
        string status = "";
        public Page8(string p_name, string p_labo)
        {
            InitializeComponent();
            this.p_name = p_name;
            this.p_labo = p_labo;
            status = "VIEWS";

            SqlConnection sqlconn = new SqlConnection(Properties.Settings.Default.sqlServer);
            using (var command = sqlconn.CreateCommand())
            {
                sqlconn.Open();
                // SQLの設定
                command.CommandText = @"SELECT id,name,labo,status,room,place_x,place_y,dt FROM cps_info";

                // SQLの実行
                using (var reader = command.ExecuteReader())
                {
                    while (reader.Read() == true)
                    {
                        Page4.user nu = new Page4.user();
                        nu.id = reader["id"] as string;
                        nu.name = reader["name"] as string;
                        nu.affiliations = reader["labo"] as string;
                        nu.status = reader["status"] as string;
                        nu.room = reader["room"] as string;
                        nu.place_x = reader["place_x"] as string;
                        nu.place_y = reader["place_y"] as string;
                        nu.dt = reader["dt"] as string;
                        uInfo.Add(nu);
                    }
                }
                sqlconn.Close();
            }
            p_id = uInfo.Find(u => u.name == p_name).id;
        }
        public void saveStatus(string str, string room)
        {
            SqlConnection sqlconn = new SqlConnection(Properties.Settings.Default.sqlServer);
            sqlconn.Open();
            DateTime dt = DateTime.Now;
            string SqlWord = "insert into cps_log(id,name,labo,status,room,place_x,place_y,dt) VALUES (@id,@name,@labo,@status,@room,@place_x,@place_y,@dt)";
            using (SqlTransaction transaction = sqlconn.BeginTransaction())
            {
                using (SqlCommand cmd = new SqlCommand(SqlWord, sqlconn, transaction))
                {
                    cmd.Parameters.Add(new SqlParameter(
                        "@id", SqlDbType.VarChar)).Value = p_id;
                    cmd.Parameters.Add(new SqlParameter(
                        "@name", SqlDbType.VarChar)).Value = p_name;
                    cmd.Parameters.Add(new SqlParameter(
                        "@labo", SqlDbType.VarChar)).Value = p_labo;
                    cmd.Parameters.Add(new SqlParameter(
                        "@status", SqlDbType.VarChar)).Value = str;
                    cmd.Parameters.Add(new SqlParameter(
                        "@room", SqlDbType.VarChar)).Value = room;
                    cmd.Parameters.Add(new SqlParameter(
                        "@place_x", SqlDbType.VarChar)).Value = "0";
                    cmd.Parameters.Add(new SqlParameter(
                        "@place_y", SqlDbType.VarChar)).Value = "0";
                    cmd.Parameters.Add(new SqlParameter(
                        "@dt", SqlDbType.VarChar)).Value = dt.ToString("yyyy/MM/dd HH:mm:ss");
                    cmd.ExecuteNonQuery();

                    transaction.Commit();
                }
            }
        }
        //204
        private void Button_Click_pro(object sender, RoutedEventArgs e)
        {
            room = "PROFESSOR";
            saveStatus(status, room);
            var page8pro = new Page8pro(p_id, p_name, p_labo, status, room);
            NavigationService.Navigate(page8pro);
        }
        //402
        private void Button_Click_402(object sender, RoutedEventArgs e)
        {
            room = "402";
            saveStatus(status, room);
            var page6402 = new Page8402(p_id, p_name, p_labo, status, room);
            NavigationService.Navigate(page6402);
        }
        //403
        private void Button_Click_403(object sender, RoutedEventArgs e)
        {
            room = "403";
            saveStatus(status, room);
            var page6403 = new Page8403(p_id, p_name, p_labo, status, room);
            NavigationService.Navigate(page6403);
        }
        //404
        private void Button_Click_404(object sender, RoutedEventArgs e)
        {
            room = "404";
            saveStatus(status, room);
            var page6404 = new Page8404(p_id, p_name, p_labo, status, room);
            NavigationService.Navigate(page6404);
        }
        //OTHER
        private void Button_Click_OTHER(object sender, RoutedEventArgs e)
        {
            room = "OTHER";
            saveStatus(status, room);
            var page6404 = new Page8other(p_id, p_name, p_labo, status, room);
            NavigationService.Navigate(page6404);
        }
        //HOME
        private void Button_Click_HOME(object sender, RoutedEventArgs e)
        {
            var page3 = new Page3(p_name, p_labo);
            NavigationService.Navigate(page3);
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            var page3 = new Page3(p_name, p_labo);
            NavigationService.Navigate(page3);
        }
    }
}