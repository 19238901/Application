﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Timers;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace CPS
{
    /// <summary>
    /// Page1.xaml の相互作用ロジック
    /// </summary>
    public partial class Page8403 : Page
    {
        List<Page4.user> u6 = new List<Page4.user>();
        string status = "";
        string p_id = "";
        string p_name = "";
        string p_labo = "";
        public Page8403(string p_id, string p_name, string p_labo, string status, string room)
        {
            InitializeComponent();
            this.p_id = p_id;
            this.p_name = p_name;
            this.p_labo = p_labo;
            this.status = status;

            ROOM.IsReadOnly = true;
            ROOM.Text = room;
            SqlConnection sqlconn = new SqlConnection(Properties.Settings.Default.sqlServer);
            using (var command = sqlconn.CreateCommand())
            {
                sqlconn.Open();
                // SQLの設定
                command.CommandText = @"SELECT id,name,labo,status,room,place_x,place_y,dt FROM cps_info";

                // SQLの実行
                using (var reader = command.ExecuteReader())
                {
                    while (reader.Read() == true)
                    {
                        Page4.user nu = new Page4.user();
                        nu.id = reader["id"] as string;
                        nu.name = reader["name"] as string;
                        nu.affiliations = reader["labo"] as string;
                        nu.status = reader["status"] as string;
                        nu.room = reader["room"] as string;
                        nu.place_x = reader["place_x"] as string;
                        nu.place_y = reader["place_y"] as string;
                        nu.dt = reader["dt"] as string;
                        u6.Add(nu);
                        if (nu.place_x == "10" && nu.place_y == "10")
                        {
                            btn11.Content = p_name;
                            btn12.Content = p_name;
                            btn13.Content = p_name;
                            btn21.Content = p_name;
                            btn22.Content = p_name;
                            btn31.Content = p_name;
                            btn32.Content = p_name;
                            btn33.Content = p_name;
                            btn34.Content = p_name;

                            var bc = new BrushConverter();
                            btn11.Background = (Brush)bc.ConvertFrom("#FFFE7474");
                            btn12.Background = (Brush)bc.ConvertFrom("#FFFE7474");
                            btn13.Background = (Brush)bc.ConvertFrom("#FFFE7474");
                            btn21.Background = (Brush)bc.ConvertFrom("#FFFE7474");
                            btn22.Background = (Brush)bc.ConvertFrom("#FFFE7474");
                            btn31.Background = (Brush)bc.ConvertFrom("#FFFE7474");
                            btn32.Background = (Brush)bc.ConvertFrom("#FFFE7474");
                            btn33.Background = (Brush)bc.ConvertFrom("#FFFE7474");
                            btn34.Background = (Brush)bc.ConvertFrom("#FFFE7474");
                        }
                        else if (nu.place_x != "0" && nu.place_y != "0" && nu.room == "403")
                        {
                            string place = "btn";
                            //色塗り/名前入れ
                            place = place + nu.place_y + nu.place_x;
                            Button tb = this.FindName(place) as Button;
                            var bc = new BrushConverter();
                            if (null != tb)
                            {
                                tb.Background = (Brush)bc.ConvertFrom("#FFFE7474");

                                tb.Content = nu.name;
                            }
                        }
                    }
                }
                sqlconn.Close();
            }
        }
        public void checkInfo(string str)
        {
            Button tb = this.FindName(str) as Button;
            if (tb.Content.ToString() != "")
            {
                MessageBox.Show(tb.Content.ToString());
            }
        }
        //11
        private void Button_Click_11(object sender, RoutedEventArgs e)
        {
            checkInfo("btn11");
        }
        //12
        private void Button_Click_12(object sender, RoutedEventArgs e)
        {
            checkInfo("btn12");
        }
        //13
        private void Button_Click_13(object sender, RoutedEventArgs e)
        {
            checkInfo("btn13");
        }
        //21
        private void Button_Click_21(object sender, RoutedEventArgs e)
        {
            checkInfo("btn21");
        }
        //22
        private void Button_Click_22(object sender, RoutedEventArgs e)
        {
            checkInfo("btn22");
        }
        //311
        private void Button_Click_311(object sender, RoutedEventArgs e)
        {
            checkInfo("btn31");
        }
        //312
        private void Button_Click_312(object sender, RoutedEventArgs e)
        {
            checkInfo("btn32");
        }
        
        //411
        private void Button_Click_411(object sender, RoutedEventArgs e)
        {
            checkInfo("btn33");
        }
        //412
        private void Button_Click_412(object sender, RoutedEventArgs e)
        {
            checkInfo("btn34");
        }
        //HOME
        private void Button_Click_HOME(object sender, RoutedEventArgs e)
        {
            var page3 = new Page3(p_name, p_labo);
            NavigationService.Navigate(page3);
        }
        //<-
        private void Button_Click(object sender, RoutedEventArgs e)
        {
            var page8 = new Page8(p_name, p_labo);
            NavigationService.Navigate(page8);
        }
        public void saveStatus(string str, string room)
        {
            SqlConnection sqlconn = new SqlConnection(Properties.Settings.Default.sqlServer);
            sqlconn.Open();
            DateTime dt = DateTime.Now;
            string SqlWord = "insert into cps_log(id,name,labo,status,room,place_x,place_y,dt) VALUES (@id,@name,@labo,@status,@room,@place_x,@place_y,@dt)";
            using (SqlTransaction transaction = sqlconn.BeginTransaction())
            {
                using (SqlCommand cmd = new SqlCommand(SqlWord, sqlconn, transaction))
                {
                    cmd.Parameters.Add(new SqlParameter(
                        "@id", SqlDbType.VarChar)).Value = p_id;
                    cmd.Parameters.Add(new SqlParameter(
                        "@name", SqlDbType.VarChar)).Value = p_name;
                    cmd.Parameters.Add(new SqlParameter(
                        "@labo", SqlDbType.VarChar)).Value = p_labo;
                    cmd.Parameters.Add(new SqlParameter(
                        "@status", SqlDbType.VarChar)).Value = str;
                    cmd.Parameters.Add(new SqlParameter(
                        "@room", SqlDbType.VarChar)).Value = room;
                    cmd.Parameters.Add(new SqlParameter(
                        "@place_x", SqlDbType.VarChar)).Value = "0";
                    cmd.Parameters.Add(new SqlParameter(
                        "@place_y", SqlDbType.VarChar)).Value = "0";
                    cmd.Parameters.Add(new SqlParameter(
                        "@dt", SqlDbType.VarChar)).Value = dt.ToString("yyyy/MM/dd HH:mm:ss");
                    cmd.ExecuteNonQuery();

                    transaction.Commit();
                }
            }
        }
        //PROFESSOR
        private void Button_Click_pro(object sender, RoutedEventArgs e)
        {
            saveStatus(status, "PROFESSOR");
            var page8pro = new Page8pro(p_id, p_name, p_labo, status, "PROFESSOR");
            NavigationService.Navigate(page8pro);
        }
        //402
        private void Button_Click_402(object sender, RoutedEventArgs e)
        {
            saveStatus(status, "402");
            var page8402 = new Page8402(p_id, p_name, p_labo, status, "402");
            NavigationService.Navigate(page8402);
        }
        //403
        private void Button_Click_403(object sender, RoutedEventArgs e)
        {
            saveStatus(status, "403");
            var page8403 = new Page8403(p_id, p_name, p_labo, status, "403");
            NavigationService.Navigate(page8403);
        }
        //404
        private void Button_Click_404(object sender, RoutedEventArgs e)
        {
            saveStatus(status, "404");
            var page8404 = new Page8404(p_id, p_name, p_labo, status, "404");
            NavigationService.Navigate(page8404);
        }
        //OTHER
        private void Button_Click_OTHER(object sender, RoutedEventArgs e)
        {
            saveStatus(status, "OTHER");
            var page8other = new Page8other(p_id, p_name, p_labo, status, "OTHER");
            NavigationService.Navigate(page8other);
        }
    }
}