﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Timers;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace CPS
{
    /// <summary>
    /// Page1.xaml の相互作用ロジック
    /// </summary>
    public partial class Page6402 : Page
    {
        List<Page4.user> u6 = new List<Page4.user>();
        string status = "";
        string p_id = "";
        string p_name = "";
        string p_labo = "";
        int count = 0;
        int x, y;
        public Page6402(string p_id, string p_name, string p_labo, string status, string room)
        {
            InitializeComponent();
            this.p_id = p_id;
            this.p_name = p_name;
            this.p_labo = p_labo;
            this.status = status;

            ROOM.IsReadOnly = true;
            ROOM.Text = room;
            SqlConnection sqlconn = new SqlConnection(Properties.Settings.Default.sqlServer);
            using (var command = sqlconn.CreateCommand())
            {
                sqlconn.Open();
                // SQLの設定
                command.CommandText = @"SELECT id,name,labo,status,room,place_x,place_y,dt FROM cps_info";

                // SQLの実行
                using (var reader = command.ExecuteReader())
                {
                    while (reader.Read() == true)
                    {
                        Page4.user nu = new Page4.user();
                        nu.id = reader["id"] as string;
                        nu.name = reader["name"] as string;
                        nu.affiliations = reader["labo"] as string;
                        nu.status = reader["status"] as string;
                        nu.room = reader["room"] as string;
                        nu.place_x = reader["place_x"] as string;
                        nu.place_y = reader["place_y"] as string;
                        nu.dt = reader["dt"] as string;
                        u6.Add(nu);
                        if (nu.place_x != "0" && nu.place_y != "0" && nu.room == "402")
                        {
                            string place = "btn";
                            //色塗り/名前入れ
                            place = place + nu.place_y + nu.place_x;
                            Button tb = this.FindName(place) as Button;
                            var bc = new BrushConverter();
                            if (null != tb)
                            {
                                tb.Background = (Brush)bc.ConvertFrom("#FFFE7474");

                                tb.Content = nu.name;
                            }
                        }
                    }
                }
                sqlconn.Close();
            }
        }
        public string getStatus()
        {
            return status;
        }
        public void saveStatus(string str, string room, int x, int y)
        {
            SqlConnection sqlconn = new SqlConnection(Properties.Settings.Default.sqlServer);
            sqlconn.Open();
            DateTime dt = DateTime.Now;
            string SqlWord = "insert into cps_log(id,name,labo,status,room,place_x,place_y,dt) VALUES (@id,@name,@labo,@status,@room,@place_x,@place_y,@dt)";
            using (SqlTransaction transaction = sqlconn.BeginTransaction())
            {
                using (SqlCommand cmd = new SqlCommand(SqlWord, sqlconn, transaction))
                {
                    cmd.Parameters.Add(new SqlParameter(
                        "@id", SqlDbType.VarChar)).Value = p_id;
                    cmd.Parameters.Add(new SqlParameter(
                        "@name", SqlDbType.VarChar)).Value = p_name;
                    cmd.Parameters.Add(new SqlParameter(
                        "@labo", SqlDbType.VarChar)).Value = p_labo;
                    cmd.Parameters.Add(new SqlParameter(
                        "@status", SqlDbType.VarChar)).Value = str;
                    cmd.Parameters.Add(new SqlParameter(
                        "@room", SqlDbType.VarChar)).Value = room;
                    cmd.Parameters.Add(new SqlParameter(
                        "@place_x", SqlDbType.VarChar)).Value = x.ToString();
                    cmd.Parameters.Add(new SqlParameter(
                        "@place_y", SqlDbType.VarChar)).Value = y.ToString();
                    cmd.Parameters.Add(new SqlParameter(
                        "@dt", SqlDbType.VarChar)).Value = dt.ToString("yyyy/MM/dd HH:mm:ss");
                    cmd.ExecuteNonQuery();

                    transaction.Commit();
                }
            }
            SqlWord = "update cps_info set id=@id,name=@name,labo=@labo,status=@status,room=@room,place_x=@place_x,place_y=@place_y,dt=@dt where id=@id";
            using (SqlTransaction transaction = sqlconn.BeginTransaction())
            {
                using (SqlCommand cmd = new SqlCommand(SqlWord, sqlconn, transaction))
                {
                    cmd.Parameters.Add(new SqlParameter(
                        "@id", SqlDbType.VarChar)).Value = p_id;
                    cmd.Parameters.Add(new SqlParameter(
                        "@name", SqlDbType.VarChar)).Value = p_name;
                    cmd.Parameters.Add(new SqlParameter(
                        "@labo", SqlDbType.VarChar)).Value = p_labo;
                    cmd.Parameters.Add(new SqlParameter(
                        "@status", SqlDbType.VarChar)).Value = str;
                    cmd.Parameters.Add(new SqlParameter(
                        "@room", SqlDbType.VarChar)).Value = room;
                    cmd.Parameters.Add(new SqlParameter(
                        "@place_x", SqlDbType.VarChar)).Value = x.ToString();
                    cmd.Parameters.Add(new SqlParameter(
                        "@place_y", SqlDbType.VarChar)).Value = y.ToString();
                    cmd.Parameters.Add(new SqlParameter(
                        "@dt", SqlDbType.VarChar)).Value = dt.ToString("yyyy/MM/dd HH:mm:ss");
                    cmd.ExecuteNonQuery();

                    transaction.Commit();
                }
            }
            sqlconn.Close();
        }
        public bool checkInfo(string str)
        {
            Button tb = this.FindName(str) as Button;
            if (tb.Content.ToString() != "")
            {
                MessageBox.Show("Already in use.");
                return false;
            }
            count = 1;
            return true;
        }
        //11
        private void Button_Click_11(object sender, RoutedEventArgs e)
        {
            if(count != 0)
            {
                return;
            }
            if(checkInfo("btn11"))
            {
                x = 1;
                y = 1;
                saveStatus(getStatus(), ROOM.Text, x, y);
                btn11.Content = p_name;

                var bc = new BrushConverter();
                btn11.Background = (Brush)bc.ConvertFrom("#FFFE7474");
            }
        }
        //12
        private void Button_Click_12(object sender, RoutedEventArgs e)
        {
            if (count != 0)
            {
                return;
            }
            if (checkInfo("btn12"))
            {
                x = 2;
                y = 1;
                saveStatus(getStatus(), ROOM.Text, x, y);
                btn12.Content = p_name;

                var bc = new BrushConverter();
                btn12.Background = (Brush)bc.ConvertFrom("#FFFE7474");
            }
        }
        //13
        private void Button_Click_13(object sender, RoutedEventArgs e)
        {
            if (count != 0)
            {
                return;
            }
            if (checkInfo("btn13"))
            {
                x = 3;
                y = 1;
                saveStatus(getStatus(), ROOM.Text, x, y);
                btn13.Content = p_name;

                var bc = new BrushConverter();
                btn13.Background = (Brush)bc.ConvertFrom("#FFFE7474");
            }
        }
        //14
        private void Button_Click_14(object sender, RoutedEventArgs e)
        {
            if (count != 0)
            {
                return;
            }
            if (checkInfo("btn14"))
            {
                x = 4;
                y = 1;
                saveStatus(getStatus(), ROOM.Text, x, y);
                btn14.Content = p_name;

                var bc = new BrushConverter();
                btn14.Background = (Brush)bc.ConvertFrom("#FFFE7474");
            }
        }
        //15
        private void Button_Click_15(object sender, RoutedEventArgs e)
        {
            if (count != 0)
            {
                return;
            }
            if (checkInfo("btn15"))
            {
                x = 5;
                y = 1;
                saveStatus(getStatus(), ROOM.Text, x, y);
                btn15.Content = p_name;

                var bc = new BrushConverter();
                btn15.Background = (Brush)bc.ConvertFrom("#FFFE7474");
            }
        }
        //16
        private void Button_Click_16(object sender, RoutedEventArgs e)
        {
            if (count != 0)
            {
                return;
            }
            if (checkInfo("btn16"))
            {
                x = 6;
                y = 1;
                saveStatus(getStatus(), ROOM.Text, x, y);
                btn16.Content = p_name;

                var bc = new BrushConverter();
                btn16.Background = (Brush)bc.ConvertFrom("#FFFE7474");
            }
        }
        //21
        private void Button_Click_21(object sender, RoutedEventArgs e)
        {
            if (count != 0)
            {
                return;
            }
            if (checkInfo("btn21"))
            {
                x = 1;
                y = 2;
                saveStatus(getStatus(), ROOM.Text, x, y);
                btn21.Content = p_name;

                var bc = new BrushConverter();
                btn21.Background = (Brush)bc.ConvertFrom("#FFFE7474");
            }
        }
        //22
        private void Button_Click_22(object sender, RoutedEventArgs e)
        {
            if (count != 0)
            {
                return;
            }
            if (checkInfo("btn22"))
            {
                x = 2;
                y = 2;
                saveStatus(getStatus(), ROOM.Text, x, y);
                btn22.Content = p_name;

                var bc = new BrushConverter();
                btn22.Background = (Brush)bc.ConvertFrom("#FFFE7474");
            }
        }
        //23
        private void Button_Click_23(object sender, RoutedEventArgs e)
        {
            if (count != 0)
            {
                return;
            }
            if (checkInfo("btn23"))
            {
                x = 3;
                y = 2;
                saveStatus(getStatus(), ROOM.Text, x, y);
                btn23.Content = p_name;

                var bc = new BrushConverter();
                btn23.Background = (Brush)bc.ConvertFrom("#FFFE7474");
            }
        }
        //24
        private void Button_Click_24(object sender, RoutedEventArgs e)
        {
            if (count != 0)
            {
                return;
            }
            if (checkInfo("btn24"))
            {
                x = 4;
                y = 2;
                saveStatus(getStatus(), ROOM.Text, x, y);
                btn24.Content = p_name;

                var bc = new BrushConverter();
                btn24.Background = (Brush)bc.ConvertFrom("#FFFE7474");
            }
        }
        //25
        private void Button_Click_25(object sender, RoutedEventArgs e)
        {
            if (count != 0)
            {
                return;
            }
            if (checkInfo("btn25"))
            {
                x = 5;
                y = 2;
                saveStatus(getStatus(), ROOM.Text, x, y);
                btn25.Content = p_name;

                var bc = new BrushConverter();
                btn25.Background = (Brush)bc.ConvertFrom("#FFFE7474");
            }
        }
        //26
        private void Button_Click_26(object sender, RoutedEventArgs e)
        {
            if (count != 0)
            {
                return;
            }
            if (checkInfo("btn26"))
            {
                x = 6;
                y = 2;
                saveStatus(getStatus(), ROOM.Text, x, y);
                btn26.Content = p_name;

                var bc = new BrushConverter();
                btn26.Background = (Brush)bc.ConvertFrom("#FFFE7474");
            }
        }
        //31
        private void Button_Click_31(object sender, RoutedEventArgs e)
        {
            if (count != 0)
            {
                return;
            }
            if (checkInfo("btn31"))
            {
                x = 1;
                y = 3;
                saveStatus(getStatus(), ROOM.Text, x, y);
                btn31.Content = p_name;

                var bc = new BrushConverter();
                btn31.Background = (Brush)bc.ConvertFrom("#FFFE7474");
            }
        }
        //32
        private void Button_Click_32(object sender, RoutedEventArgs e)
        {
            if (count != 0)
            {
                return;
            }
            if (checkInfo("btn32"))
            {
                x = 2;
                y = 3;
                saveStatus(getStatus(), ROOM.Text, x, y);
                btn32.Content = p_name;

                var bc = new BrushConverter();
                btn32.Background = (Brush)bc.ConvertFrom("#FFFE7474");
            }
        }
        //33
        private void Button_Click_33(object sender, RoutedEventArgs e)
        {
            if (count != 0)
            {
                return;
            }
            if (checkInfo("btn33"))
            {
                x = 3;
                y = 3;
                saveStatus(getStatus(), ROOM.Text, x, y);
                btn33.Content = p_name;

                var bc = new BrushConverter();
                btn33.Background = (Brush)bc.ConvertFrom("#FFFE7474");
            }
        }
        //34
        private void Button_Click_34(object sender, RoutedEventArgs e)
        {
            if (count != 0)
            {
                return;
            }
            if (checkInfo("btn34"))
            {
                x = 4;
                y = 3;
                saveStatus(getStatus(), ROOM.Text, x, y);
                btn34.Content = p_name;

                var bc = new BrushConverter();
                btn34.Background = (Brush)bc.ConvertFrom("#FFFE7474");
            }
        }
        //35
        private void Button_Click_35(object sender, RoutedEventArgs e)
        {
            if (count != 0)
            {
                return;
            }
            if (checkInfo("btn35"))
            {
                x = 5;
                y = 3;
                saveStatus(getStatus(), ROOM.Text, x, y);
                btn35.Content = p_name;

                var bc = new BrushConverter();
                btn35.Background = (Brush)bc.ConvertFrom("#FFFE7474");
            }
        }
        //36
        private void Button_Click_36(object sender, RoutedEventArgs e)
        {
            if (count != 0)
            {
                return;
            }
            if (checkInfo("btn36"))
            {
                x = 6;
                y = 3;
                saveStatus(getStatus(), ROOM.Text, x, y);
                btn36.Content = p_name;

                var bc = new BrushConverter();
                btn36.Background = (Brush)bc.ConvertFrom("#FFFE7474");
            }
        }

        //41
        private void Button_Click_41(object sender, RoutedEventArgs e)
        {
            if (count != 0)
            {
                return;
            }
            if (checkInfo("btn41"))
            {
                x = 1;
                y = 4;
                saveStatus(getStatus(), ROOM.Text, x, y);
                btn41.Content = p_name;

                var bc = new BrushConverter();
                btn41.Background = (Brush)bc.ConvertFrom("#FFFE7474");
            }
        }
        //42
        private void Button_Click_42(object sender, RoutedEventArgs e)
        {
            if (count != 0)
            {
                return;
            }
            if (checkInfo("btn42"))
            {
                x = 2;
                y = 4;
                saveStatus(getStatus(), ROOM.Text, x, y);
                btn42.Content = p_name;

                var bc = new BrushConverter();
                btn42.Background = (Brush)bc.ConvertFrom("#FFFE7474");
            }
        }
        //43
        private void Button_Click_43(object sender, RoutedEventArgs e)
        {
            if (count != 0)
            {
                return;
            }
            if (checkInfo("btn43"))
            {
                x = 3;
                y = 4;
                saveStatus(getStatus(), ROOM.Text, x, y);
                btn43.Content = p_name;

                var bc = new BrushConverter();
                btn43.Background = (Brush)bc.ConvertFrom("#FFFE7474");
            }
        }
        //HOME
        private void Button_Click_HOME(object sender, RoutedEventArgs e)
        {
            var page3 = new Page3(p_name, p_labo);
            NavigationService.Navigate(page3);
        }

        //<-
        private void Button_Click(object sender, RoutedEventArgs e)
        {
            var page5 = new Page5(p_id, p_name, p_labo, getStatus());
            NavigationService.Navigate(page5);
        }
    }
}