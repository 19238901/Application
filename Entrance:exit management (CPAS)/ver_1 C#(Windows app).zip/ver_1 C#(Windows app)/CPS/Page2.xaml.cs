﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace CPS
{
    /// <summary>
    /// Page5.xaml の相互作用ロジック
    /// </summary>

    public partial class Page2 : Page
    {
        List<Page1.user> U = new List<Page1.user>();
        public Page2(List<Page1.user> u4)
        {
            InitializeComponent();
            this.U = u4;
        }
        //LOG IN
        private void Button_Click(object sender, RoutedEventArgs e)
        {
            var page1 = new Page1();
            NavigationService.Navigate(page1);
        }
        //REGISTRATION
        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
            Player_Id.BorderBrush = Brushes.Black;
            Player_Name.BorderBrush = Brushes.Black;
            Player_From.BorderBrush = Brushes.Black;
            Player_Pass.BorderBrush = Brushes.Black;
            string care = "";
            int h = 0;
            if (Player_Id.Text != "")
            {
                if (Player_Id.Text.Contains(",") || Player_Id.Text.Contains(" "))
                {
                    care = care + "Can't use [,] or [ ] for ID.\n";
                    Player_Id.Text = "";
                    Player_Id.BorderBrush = Brushes.Red;
                    h = 1;
                }
                if (U.Any(u => u.id == Player_Id.Text))
                {
                    care = care + "The ID entered is already in use.\nEnter a different ID.\n";
                    Player_Id.Text = "";
                    Player_Id.BorderBrush = Brushes.Red;
                    h = 1;
                }
                if (Player_Id.Text == "Guest")
                {
                    care = care + "Can't use that ID.\nEnter a different ID.\n";
                    Player_Id.Text = "";
                    Player_Id.BorderBrush = Brushes.Red;
                    h = 1;
                }
            }
            else
            {
                if (Player_Id.Text == "")
                {
                    Player_Id.BorderBrush = Brushes.Red;
                    care = care + "Enter the ID\n";
                    h = 1;
                }
            }
            if (Player_Name.Text != "")
            {
                if (Player_Name.Text.Contains(",") || Player_Name.Text.Contains(" "))
                {
                    care = care + "Can't use [,] or [ ] for NAME.\n";
                    Player_Name.BorderBrush = Brushes.Red;
                    Player_Name.Text = "";
                    h = 1;
                }
                if (U.Any(u => u.name == Player_Name.Text))
                {
                    care = care + "The NAME entered is already in use.\nEnter a different NAME.\n";
                    Player_Name.Text = "";
                    Player_Name.BorderBrush = Brushes.Red;
                    h = 1;
                }
                if (Player_Name.Text == "Guest")
                {
                    care = care + "Can't use that NAME.\nEnter a different NAME.\n";
                    Player_Name.Text = "";
                    Player_Name.BorderBrush = Brushes.Red;
                    h = 1;
                }
            }
            else
            {
                if (Player_Name.Text == "")
                {
                    Player_Name.BorderBrush = Brushes.Red;
                    care = care + "Enter the NAME\n";
                    h = 1;
                }
            }
            if (Player_Pass.Text != "")
            {
                if (Player_From.Text.Contains(",") || Player_From.Text.Contains(" "))
                {
                    care = care + "Can't use [,] or [ ] for FROM.\n";
                    Player_From.Text = "";
                    Player_From.BorderBrush = Brushes.Red;
                    h = 1;
                }
            }
            else
            {
                if (Player_Pass.Text == "")
                {
                    Player_Pass.BorderBrush = Brushes.Red;
                    care = care + "Enter the PASS\n";
                    h = 1;
                }
            }
            if (Player_From.Text != "")
            {
                if (Player_Pass.Text.Contains(",") || Player_Pass.Text.Contains(" "))
                {
                    care = care + "Can't use [,] or [ ] for PASS.\n";

                    Player_Pass.BorderBrush = Brushes.Red;
                    Player_Pass.Text = "";
                    h = 1;
                }
            }
            else
            {
                if (Player_From.Text == "")
                {
                    Player_From.BorderBrush = Brushes.Red;
                    care = care + "Enter the FROM\n";
                    h = 1;
                }
            }
            if (h != 0)
            {
                MessageBox.Show(care);
                return;
            }

            if (Player_Id.Text != "" && Player_Name.Text != "" && Player_Pass.Text != "" && Player_From.Text != "")
            {
                care = "Registration complete!\nPlayer INFO:\nID:" + Player_Id.Text + "\nName:" + Player_Name.Text + "\nPass:" + Player_Pass.Text + "\nLabo:" + Player_From.Text;
                string SqlWord = "insert into cps_user(id,name,pass,labo) VALUES (@id,@name,@pass,@labo)";
                SqlConnection sqlconn = new SqlConnection(Properties.Settings.Default.sqlServer);
                sqlconn.Open();
                using (SqlTransaction transaction = sqlconn.BeginTransaction())
                {
                    using (SqlCommand cmd = new SqlCommand(SqlWord, sqlconn, transaction))
                    {
                        cmd.Parameters.Add(new SqlParameter(
                            "@id", SqlDbType.VarChar)).Value = Player_Id.Text;
                        cmd.Parameters.Add(new SqlParameter(
                            "@name", SqlDbType.VarChar)).Value = Player_Name.Text;
                        cmd.Parameters.Add(new SqlParameter(
                            "@pass", SqlDbType.VarChar)).Value = Player_Pass.Text;
                        cmd.Parameters.Add(new SqlParameter(
                            "@labo", SqlDbType.VarChar)).Value = Player_From.Text;
                        cmd.ExecuteNonQuery();

                        transaction.Commit();
                    }
                }
                using (SqlTransaction transaction = sqlconn.BeginTransaction())
                {
                    SqlWord = "insert into cps_info(id,name,labo,status,room,place_x,place_y,dt) VALUES (@id,@name,@labo,@status,@room,@place_x,@place_y,@dt)";
                    DateTime dt = DateTime.Now;
                    using (SqlCommand cmd = new SqlCommand(SqlWord, sqlconn, transaction))
                    {
                        cmd.Parameters.Add(new SqlParameter(
                            "@id", SqlDbType.VarChar)).Value = Player_Id.Text;
                        cmd.Parameters.Add(new SqlParameter(
                            "@name", SqlDbType.VarChar)).Value = Player_Name.Text;
                        cmd.Parameters.Add(new SqlParameter(
                            "@labo", SqlDbType.VarChar)).Value = Player_From.Text;
                        cmd.Parameters.Add(new SqlParameter(
                            "@status", SqlDbType.VarChar)).Value = " ";
                        cmd.Parameters.Add(new SqlParameter(
                            "@room", SqlDbType.VarChar)).Value = " ";
                        cmd.Parameters.Add(new SqlParameter(
                            "@place_x", SqlDbType.VarChar)).Value = "0";
                        cmd.Parameters.Add(new SqlParameter(
                            "@place_y", SqlDbType.VarChar)).Value = "0";
                        cmd.Parameters.Add(new SqlParameter(
                            "@dt", SqlDbType.VarChar)).Value = dt.ToString("yyyy/MM/dd HH:mm:ss");
                        cmd.ExecuteNonQuery();

                        transaction.Commit();
                    }
                }
                using (SqlTransaction transaction = sqlconn.BeginTransaction())
                {
                    DateTime dt = DateTime.Now;
                    SqlWord = "insert into cps_log(id,name,labo,status,room,place_x,place_y,dt) VALUES (@id,@name,@labo,@status,@room,@place_x,@place_y,@dt)";
                    using (SqlCommand cmd = new SqlCommand(SqlWord, sqlconn, transaction))
                    {
                        cmd.Parameters.Add(new SqlParameter(
                            "@id", SqlDbType.VarChar)).Value = Player_Id.Text;
                        cmd.Parameters.Add(new SqlParameter(
                            "@name", SqlDbType.VarChar)).Value = Player_Name.Text;
                        cmd.Parameters.Add(new SqlParameter(
                            "@labo", SqlDbType.VarChar)).Value = Player_From.Text;
                        cmd.Parameters.Add(new SqlParameter(
                            "@status", SqlDbType.VarChar)).Value = "Registration";
                        cmd.Parameters.Add(new SqlParameter(
                            "@room", SqlDbType.VarChar)).Value = "-";
                        cmd.Parameters.Add(new SqlParameter(
                            "@place_x", SqlDbType.VarChar)).Value = "0";
                        cmd.Parameters.Add(new SqlParameter(
                            "@place_y", SqlDbType.VarChar)).Value = "0";
                        cmd.Parameters.Add(new SqlParameter(
                            "@dt", SqlDbType.VarChar)).Value = dt.ToString("yyyy/MM/dd HH:mm:ss");
                        cmd.ExecuteNonQuery();

                        transaction.Commit();
                    }
                }
                sqlconn.Close();
                Player_Id.Text = "";
                Player_Name.Text = "";
                Player_Pass.Text = "";
                Player_From.Text = "";
                
            }
            MessageBox.Show(care);
        }
        //ALL CLEAR
        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            Player_Id.Text = "";
            Player_Name.Text = "";
            Player_Pass.Text = "";
            Player_From.Text = "";
        }
    }
}
