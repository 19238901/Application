﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace CPS
{
    /// <summary>
    /// Page5.xaml の相互作用ロジック
    /// </summary>

    public partial class Page91 : Page
    {
        List<Page4.user> uInfo = new List<Page4.user>();
        string p_name = "";
        string p_labo = "";
        string s_id = "";
        string s_name = "";
        string s_labo = "";
        string s_room = "";
        string s_date = "";
        public Page91(string p_name, string p_from, string id,string name,string labo,string room,string date)
        {
            InitializeComponent();
            this.p_name = p_name;
            this.p_labo = p_from;
            this.s_id = id;
            this.s_name = name;
            this.s_labo = labo;
            this.s_room = room;
            this.s_date = date;
            Player_Id.Text = id;
            Player_Name.Text = name;
            Player_From.Text = labo;
            ROOM.Text = room;
            if (date != "")
            {
                string[] arr = date.Split('/');
                DATE_y.Text = arr[0];
                DATE_m.Text = arr[1];
                DATE_d.Text = arr[2];
            }
        }
        //SEARCH
        private void Button_Click_SEARCH(object sender, RoutedEventArgs e)
        {
            string s_date1 = "";
            if (DATE_y.Text != "" && DATE_m.Text != "" && DATE_d.Text != "")
            {
                if (DATE_m.Text == "1")
                {
                    DATE_m.Text = "01";
                }
                else if (DATE_m.Text == "2")
                {
                    DATE_m.Text = "02";
                }
                else if (DATE_m.Text == "3")
                {
                    DATE_m.Text = "03";
                }
                else if (DATE_m.Text == "4")
                {
                    DATE_m.Text = "04";
                }
                else if (DATE_m.Text == "5")
                {
                    DATE_m.Text = "05";
                }
                else if (DATE_m.Text == "6")
                {
                    DATE_m.Text = "06";
                }
                else if (DATE_m.Text == "7")
                {
                    DATE_m.Text = "07";
                }
                else if (DATE_m.Text == "8")
                {
                    DATE_m.Text = "08";
                }
                else if (DATE_m.Text == "9")
                {
                    DATE_m.Text = "09";
                }


                if (DATE_d.Text == "1")
                {
                    DATE_d.Text = "01";
                }
                else if (DATE_d.Text == "2")
                {
                    DATE_d.Text = "02";
                }
                else if (DATE_d.Text == "3")
                {
                    DATE_d.Text = "03";
                }
                else if (DATE_d.Text == "4")
                {
                    DATE_d.Text = "04";
                }
                else if (DATE_d.Text == "5")
                {
                    DATE_d.Text = "05";
                }
                else if (DATE_d.Text == "6")
                {
                    DATE_d.Text = "06";
                }
                else if (DATE_d.Text == "7")
                {
                    DATE_d.Text = "07";
                }
                else if (DATE_d.Text == "8")
                {
                    DATE_d.Text = "08";
                }
                else if (DATE_d.Text == "9")
                {
                    DATE_d.Text = "09";
                }
                s_date1 = DATE_y.Text + "/" + DATE_m.Text + "/" + DATE_d.Text;
            }
            var page9 = new Page9(p_name, p_labo, Player_Id.Text, Player_Name.Text, Player_From.Text, ROOM.Text, "", "", s_date1, "ALL");
            NavigationService.Navigate(page9);
        }
        //SEAT
        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
            string s_date1 = "";
            if (DATE_y.Text != "" && DATE_m.Text != "" && DATE_d.Text != "")
            {
                if (DATE_m.Text == "1")
                {
                    DATE_m.Text = "01";
                }
                else if (DATE_m.Text == "2")
                {
                    DATE_m.Text = "02";
                }
                else if (DATE_m.Text == "3")
                {
                    DATE_m.Text = "03";
                }
                else if (DATE_m.Text == "4")
                {
                    DATE_m.Text = "04";
                }
                else if (DATE_m.Text == "5")
                {
                    DATE_m.Text = "05";
                }
                else if (DATE_m.Text == "6")
                {
                    DATE_m.Text = "06";
                }
                else if (DATE_m.Text == "7")
                {
                    DATE_m.Text = "07";
                }
                else if (DATE_m.Text == "8")
                {
                    DATE_m.Text = "08";
                }
                else if (DATE_m.Text == "9")
                {
                    DATE_m.Text = "09";
                }


                if (DATE_d.Text == "1")
                {
                    DATE_d.Text = "01";
                }
                else if (DATE_d.Text == "2")
                {
                    DATE_d.Text = "02";
                }
                else if (DATE_d.Text == "3")
                {
                    DATE_d.Text = "03";
                }
                else if (DATE_d.Text == "4")
                {
                    DATE_d.Text = "04";
                }
                else if (DATE_d.Text == "5")
                {
                    DATE_d.Text = "05";
                }
                else if (DATE_d.Text == "6")
                {
                    DATE_d.Text = "06";
                }
                else if (DATE_d.Text == "7")
                {
                    DATE_d.Text = "07";
                }
                else if (DATE_d.Text == "8")
                {
                    DATE_d.Text = "08";
                }
                else if (DATE_d.Text == "9")
                {
                    DATE_d.Text = "09";
                }
                s_date1 = DATE_y.Text + "/" + DATE_m.Text + "/" + DATE_d.Text;
            }
            if (ROOM.Text == "402" || ROOM.Text == "")
            {
                var page3 = new Page9402(p_name, p_labo, Player_Id.Text, Player_Name.Text, Player_From.Text, "402", s_date1);
                NavigationService.Navigate(page3);
            }
            else if (ROOM.Text == "403")
            {
                var page3 = new Page9403(p_name, p_labo, Player_Id.Text, Player_Name.Text, Player_From.Text, ROOM.Text, s_date1);
                NavigationService.Navigate(page3);
            }
            else if (ROOM.Text == "404")
            {
                var page3 = new Page9404(p_name, p_labo, Player_Id.Text, Player_Name.Text, Player_From.Text, ROOM.Text, s_date1);
                NavigationService.Navigate(page3);
            }
        }
        //ALL CLEAR
        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            Player_Id.Text = "";
            Player_Name.Text = "";
            ROOM.Text = "";
            Player_From.Text = "";
            DATE_d.Text = "";
            DATE_m.Text = "";
            DATE_y.Text = "";
        }
        //<-
        private void Button_Click_back(object sender, RoutedEventArgs e)
        {
            var page9 = new Page9(p_name, p_labo, s_id, s_name, s_labo, s_room, "", "", s_date, "ALL");
            NavigationService.Navigate(page9);
        }
    }
}
