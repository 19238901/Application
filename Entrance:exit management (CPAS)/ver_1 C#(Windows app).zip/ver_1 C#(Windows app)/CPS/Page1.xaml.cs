﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace CPS
{
    /// <summary>
    /// Page1.xaml の相互作用ロジック
    /// </summary>
    public partial class Page1 : Page
    {
        public class user
        {
            public string id { get; set; }
            public string name { get; set; }
            public string pass { get; set; }
            public string affiliations { get; set; }
        }
        List<user> U = new List<user>();
        string p_name = "-";
        string p_labo = "-";
        public Page1()
        {
            InitializeComponent();
            try
            {
                SqlConnection sqlconn = new SqlConnection(Properties.Settings.Default.sqlServer);
                using (var command = sqlconn.CreateCommand())
                {
                    sqlconn.Open();
                    // SQLの設定
                    command.CommandText = @"SELECT id,name,pass,labo FROM dbo.cps_user";

                    // SQLの実行
                    using (var reader = command.ExecuteReader())
                    {
                        while (reader.Read() == true)
                        {
                            user nu = new user();
                            nu.id = reader["id"] as string;
                            nu.name = reader["name"] as string;
                            nu.pass = reader["pass"] as string;
                            nu.affiliations = reader["labo"] as string;
                            U.Add(nu);
                        }
                    }
                    sqlconn.Close();
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
        }
        //LOG IN
        private void Button_Click(object sender, RoutedEventArgs e)
        {
            double ha = 0;
            string care = "";
            if (Player_Id.Text == "")
            {
                care = care + "Enter your ID.\n";
                Player_Id.BorderBrush = Brushes.Red;
                ha = 1;
            }
            else
            {
                Player_Id.BorderBrush = Brushes.Black;
            }
            if (Player_Pass.Text == "")
            {
                care = care + "Enter your Pass.\n";
                Player_Pass.BorderBrush = Brushes.Red;
                ha = 2;
            }
            else
            {
                Player_Pass.BorderBrush = Brushes.Black;
            }
            if (ha != 0)
            {
                MessageBox.Show(care);
                return;
            }

            List<user> u4n = U.FindAll(u => u.id == Player_Id.Text);
            if (u4n.Count == 0)
            {
                MessageBox.Show("Different ID.\n");
                Player_Id.Text = "";
                Player_Pass.Text = "";
                Player_Pass.BorderBrush = Brushes.Red;
                Player_Id.BorderBrush = Brushes.Red;
                ha = 1;
            }
            else
            {
                if (U.Find(u => u.id == Player_Id.Text).pass == Player_Pass.Text)
                {
                    var page3 = new Page3(U.Find(u => u.id == Player_Id.Text).name, U.Find(u => u.id == Player_Id.Text).affiliations);
                    NavigationService.Navigate(page3);
                }
                else
                {
                    MessageBox.Show("Different Pass.\n");
                    Player_Pass.Text = "";
                    Player_Pass.BorderBrush = Brushes.Red;
                    Player_Id.BorderBrush = Brushes.Black;
                    ha = 2;
                }
            }
            if (ha == 0)
            {
                p_name = U.Find(u => u.id == Player_Id.Text).name;
                p_labo = U.Find(u => u.id == Player_Id.Text).affiliations;
            }
            SqlConnection sqlconn1 = new SqlConnection(Properties.Settings.Default.sqlServer);
            sqlconn1.Open();
            using (SqlTransaction transaction1 = sqlconn1.BeginTransaction())
            {
                DateTime dt = DateTime.Now;
                string SqlWord2 = "insert into cps_log(id,name,labo,status,room,place_x,place_y,dt) VALUES (@id,@name,@labo,@status,@room,@place_x,@place_y,@dt)";
                using (SqlCommand cmd2 = new SqlCommand(SqlWord2, sqlconn1, transaction1))
                {
                    cmd2.Parameters.Add(new SqlParameter(
                        "@id", SqlDbType.VarChar)).Value = Player_Id.Text;
                    cmd2.Parameters.Add(new SqlParameter(
                        "@name", SqlDbType.VarChar)).Value = p_name;
                    cmd2.Parameters.Add(new SqlParameter(
                        "@labo", SqlDbType.VarChar)).Value = p_labo;
                    cmd2.Parameters.Add(new SqlParameter(
                        "@status", SqlDbType.VarChar)).Value = "Log in";
                    if (ha == 0)
                    {
                        cmd2.Parameters.Add(new SqlParameter(
                        "@room", SqlDbType.VarChar)).Value = "Success";
                    }
                    else
                    {
                        cmd2.Parameters.Add(new SqlParameter(
                        "@room", SqlDbType.VarChar)).Value = "Miss";
                    }
                    cmd2.Parameters.Add(new SqlParameter(
                        "@place_x", SqlDbType.VarChar)).Value = "0";
                    cmd2.Parameters.Add(new SqlParameter(
                        "@place_y", SqlDbType.VarChar)).Value = "0";
                    cmd2.Parameters.Add(new SqlParameter(
                        "@dt", SqlDbType.VarChar)).Value = dt.ToString("yyyy/MM/dd HH:mm:ss");
                    
                    cmd2.ExecuteNonQuery();

                    transaction1.Commit();
                }
            }
            sqlconn1.Close();
            /*
            SqlConnection sqlconn = new SqlConnection(Properties.Settings.Default.sqlServer);
            sqlconn.Open();
            string SqlWord = "insert into cps_log(id,name,labo,status,room,place_x,place_y,dt) VALUES (@id,@name,@labo,@status,@room,@place_x,@place_y,@dt)";
            using (SqlTransaction transaction = sqlconn.BeginTransaction())
            {
                DateTime dt = DateTime.Now;

                using (SqlCommand cmd = new SqlCommand(SqlWord, sqlconn, transaction))
                {
                    cmd.Parameters.Add(new SqlParameter(
                        "@id", SqlDbType.VarChar)).Value = Player_Id.Text;
                    cmd.Parameters.Add(new SqlParameter(
                        "@name", SqlDbType.VarChar)).Value = U.Find(u => u.id == Player_Id.Text).name;
                    cmd.Parameters.Add(new SqlParameter(
                        "@labo", SqlDbType.VarChar)).Value = U.Find(u => u.id == Player_Id.Text).affiliations;
                    cmd.Parameters.Add(new SqlParameter(
                        "@status", SqlDbType.VarChar)).Value = "Log in";
                    if (ha == 0)
                    {
                        cmd.Parameters.Add(new SqlParameter(
                        "@room", SqlDbType.VarChar)).Value = "success";
                    }
                    else
                    {
                        cmd.Parameters.Add(new SqlParameter(
                        "@room", SqlDbType.VarChar)).Value = "miss";
                    }
                    cmd.Parameters.Add(new SqlParameter(
                        "@place_x", SqlDbType.VarChar)).Value = "0";
                    cmd.Parameters.Add(new SqlParameter(
                        "@place_y", SqlDbType.VarChar)).Value = "0";
                    cmd.Parameters.Add(new SqlParameter(
                        "@dt", SqlDbType.VarChar)).Value = dt.ToString("yyyy/MM/dd HH:mm:ss");
                    transaction.Commit();
                }
            }*/
        }
        //NEW PLAYER
        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
            var page5 = new Page2(U);
            NavigationService.Navigate(page5);
        }
    }
}
